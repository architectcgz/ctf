priority: compose.env > service.env > .env
