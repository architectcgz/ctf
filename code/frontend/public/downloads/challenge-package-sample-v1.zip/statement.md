# Web Demo

这是一个示例题目包，用于演示 challenge.yml 字段与目录结构。
你可以在此基础上修改题目标题、分类、难度、分值、附件和 Flag。
