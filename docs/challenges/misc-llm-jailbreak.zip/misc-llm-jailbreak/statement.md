# LLM 越狱

## 题目描述

连接服务获取 flag。

## 知识点

- kp:llm
