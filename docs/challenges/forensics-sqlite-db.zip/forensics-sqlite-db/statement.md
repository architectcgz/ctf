# SQLite 数据库取证

## 题目描述

分析附件获取 flag。

## 知识点

- kp:sqlite
