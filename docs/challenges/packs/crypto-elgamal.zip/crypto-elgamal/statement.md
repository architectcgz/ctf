# ElGamal 弱参数

## 题目描述

解密获取 flag。
