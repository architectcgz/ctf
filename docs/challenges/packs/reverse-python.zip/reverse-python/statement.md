# Python 字节码

## 题目描述

逆向获取 flag。
