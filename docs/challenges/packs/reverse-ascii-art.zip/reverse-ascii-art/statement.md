# ASCII 艺术

## 题目描述

逆向二进制文件获取 flag。
