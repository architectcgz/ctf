# GraphQL 越权

## 题目描述

待补充

## 目标

获取 flag。
