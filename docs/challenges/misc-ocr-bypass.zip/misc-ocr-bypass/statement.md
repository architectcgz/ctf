# OCR 识别绕过

## 题目描述

连接服务获取 flag。

## 知识点

- kp:ocr
