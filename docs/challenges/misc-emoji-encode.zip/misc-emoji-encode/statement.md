# Emoji 编码

## 题目描述

解析附件获取 flag。

## 知识点

- kp:emoji
